#ifndef ASTEROIDE_H_
#define ASTEROIDE_H_

#include <unistd.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <math.h>

class Asteroide{
    private:
        int CoordX; //coordenadas del centro del poligono
        int CoordY; //coordenadas del centro del poligono
        int rad=10; //radio inicial del poligono
        int Cuadr; //Cuadrante del que va a salir el poligono
	float ArrY[60]; //arreglo de vertices en eje Y
        float ArrX[60]; //arreglo de vertices en eje X
        int Vert; //total de vertices del poligono
        int Tam;
        int maxRad;
        vector<int> Radios;
        
    public:
        vector<int> Tray(); //Trayectoria del vector
        void ImpAst(Asteroide[]);
        void Ast(int, int, int, int);
        void Ast2(int, int);
        int getMaxRad();
};

#endif
