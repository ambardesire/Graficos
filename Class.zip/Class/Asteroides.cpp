#include "gfx.h"
#include "Asteroide.h"

#include <unistd.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <math.h>

using namespace std;

int main(int argc, char *argv[]){
	NUMERO_ASTEROIDES = atoi(argv[1]);	
	int Num, Tam, CoorX, CoorY;
	Asteroide a[NUMERO_ASTEROIDES];
	int Cont=0; 
	
    srand(time(NULL));
    gfx_open(700, 700, "Asteroides");
    gfx_color(0, 250, 0);
    CoorY = rand()%601;
    
    while(Cont<NUMERO_ASTEROIDES){
        Num = rand() % 4; //Elegir al azar el cuadrante del que saldra el poligono
        //Determinar cuadrante y punto por donde saldra el poligono
        if(Num==0){
            CoorX = 0;
            CoorY = rand()%601;
        }
        else if(Num==1){
            CoorX = rand()%801;
            CoorY = 0;
            }
                else if(Num==2){
                    CoorX = 800;
                    CoorY = rand()%601;
                }
                    else if(Num==3){
                        CoorX = rand()%801;
                        CoorY = 600;
                    }
        
        Tam = 1 + rand() % (6 - 1);
        a[Cont].Ast(CoorX, CoorY, Num, Tam);
        Cont++;
    }

    while(1){
        a[Cont].ImpAst(a);
        gfx_flush();
        gfx_clear();
    }
    return 0;
}
